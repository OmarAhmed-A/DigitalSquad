def cipher_solver(question):
    pass

def captcha_solver(question):
    # Return solution
    pass

def pcap_solver(question):
    # Return solution
    pass

def server_solver(question):
    # Return solution
    pass